#!/bin/bash

# nvim URL 핸들러 스크립트 (Ghostty 터미널용)
NVIM_BIN="/opt/homebrew/bin/nvim"
SERVER_PIPE="$HOME/.cache/nvim/server.pipe"

# URL에서 파일 정보 추출
url="$1"
file_info="${url#nvim://file/}"

# 파일 경로, 라인, 컬럼 분리
file_path="$file_info"
line=""
column=""

# 라인과 컬럼 번호 파싱
if [[ "$file_info" =~ ^(.+):([0-9]+):([0-9]+)$ ]]; then
    file_path="${BASH_REMATCH[1]}"
    line="${BASH_REMATCH[2]}"
    column="${BASH_REMATCH[3]}"
elif [[ "$file_info" =~ ^(.+):([0-9]+)$ ]]; then
    file_path="${BASH_REMATCH[1]}"
    line="${BASH_REMATCH[2]}"
fi

# nvim server가 실행 중인지 확인
if ! pgrep -f "nvim.*listen.*server.pipe" > /dev/null; then
    # nvim server가 없으면 Ghostty에서 새로 시작
    if [ -n "$line" ]; then
        nvim_cmd="$NVIM_BIN --listen $SERVER_PIPE +$line '$file_path'"
    else
        nvim_cmd="$NVIM_BIN --listen $SERVER_PIPE '$file_path'"
    fi
    
    # Ghostty로 새 창에서 nvim 실행
    open -a Ghostty --args -e bash -c "$nvim_cmd"
    exit 0
fi

# 파일 열기
"$NVIM_BIN" --server "$SERVER_PIPE" --remote "$file_path"

# 라인으로 이동
if [ -n "$line" ]; then
    "$NVIM_BIN" --server "$SERVER_PIPE" --remote-send "${line}gg"
    
    # 컬럼으로 이동
    if [ -n "$column" ]; then
        "$NVIM_BIN" --server "$SERVER_PIPE" --remote-send "${column}|"
    fi
fi

# Ghostty를 앞으로 가져오기
osascript -e "tell application \"Ghostty\" to activate"